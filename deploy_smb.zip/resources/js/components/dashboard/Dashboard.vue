<template>
  <div
    class="d-flex justify-center align-center"
    style="height: 100vh; background-color: #121212;"
  >
    <v-img
      src="/material-belico.png"
      alt="Seção de Material Bélico"
      contain
      max-width="400"
    />
  </div>
</template>