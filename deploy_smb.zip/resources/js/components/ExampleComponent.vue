<template>
  <main class="max-w-4xl mx-auto p-6 bg-gray-100 rounded-lg shadow-md mt-10">
    <h1 class="text-3xl font-bold underline text-blue-600 mb-6">
      Hello world!
    </h1>

    <p class="text-gray-700 mb-4">
      Este é um exemplo de texto estilizado com Tailwind CSS.
    </p>

    <button
      class="bg-blue-600 hover:bg-blue-700 text-white font-semibold py-2 px-4 rounded transition-colors duration-300"
    >
      Clique aqui
    </button>
  </main>
</template>

<script setup>
// Script setup (Vue 3 moderno)
</script>
